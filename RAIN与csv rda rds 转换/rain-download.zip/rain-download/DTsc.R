library(shiny)
library(lattice)
library(rain)
library(DT)

mod_rda_file_ui <- function(id, label = "RDA file"){
  ns <- NS(id)
  tagList(
    fileInput(ns("file"), label, accept = c("*")),
    checkboxInput(ns("heading"), "Has heading")
  )
}

mod_rda_file_server  <- function(id) {
  moduleServer(
    id,
    function(input, output, session) {
      userFile <- reactive({
        input$file
      })
      dataframe <- reactive({
        if (!is.null(userFile())) {
          readRDS(userFile()$datapath)
        }
      })
      return(dataframe)
    }
  )
}

ui <- fluidPage(
  sidebarLayout(
    sidebarPanel(
      mod_rda_file_ui("datafile", "User data (.rda format)"),
      numericInput("num1", label = "deltat", value = 4),
      numericInput("num2", label = "period", value = 24),
      numericInput("num3", label = "nr.series", value = 2),
      numericInput("num5", label = "period_delta", value = 0),
      selectInput("method", "Method", choices = c("Independent", "Longitudinal"), selected = "Independent"),
      checkboxInput("na_rm", "Remove NAs", value = FALSE),
      selectInput("adjp_method", "Adjust P-Value", choices = c("ABH", "BY", "BH"), selected = "ABH"),
      sliderInput("peak", label = "Peak Border", min = 0, max = 1, value = c(0.3, 0.7), step = 0.1),
      radioButtons("verbose", label = "Verbose", choices = c("TRUE", "FALSE"), selected = "FALSE"),
      actionButton("refresh", "Refresh"),
      downloadButton("download_data", "Download Data")
    ),
    mainPanel(
      dataTableOutput("table"),
      DT::dataTableOutput("rain_matrix"),
      mainPanel(
        plotOutput("curve_plot")
      )
    )
  )
)

server <- function(input, output, session) {

  datafile <- mod_rda_file_server("datafile")

  output$table <- renderDataTable({
    datafile()
  })

  data <- reactive({
    if (is.null(datafile())) return(NULL)
    datafile()
  })

  output$curve_plot <- shiny::renderPlot({
    if(is.null(data())){
      showModal(modalDialog(
        title = "Error",
        "Please upload a file first!"
      ))
    } else {
      results <- rain(t(as.matrix(data())),
                      deltat = input$num1,
                      period = input$num2,
                      nr.series = input$num3,
                      peak.border = input$peak,
                      verbose = as.logical(input$verbose))
      best <- order(results$pVal)[1:10]
      xyplot(as.matrix(data()
                       [best, (0:5 * 2 + rep(c(1, 2), each = 6))])
             ~rep(0:11 * 4 + 2, each = 10) |rownames(data())[best],
             scales = list(y = list(relation = 'free')),
             layout = c(2, 5), type = 'b', pch = 16, xlab = 'time',
             ylab = 'expression value', cex.lab = 1)
    }
  })

  output$rain_matrix <- DT::renderDT({
    if(is.null(data())) return(NULL)
    results <- rain(t(as.matrix(data())),
                    deltat = input$num1,
                    period = input$num2,
                    nr.series = input$num3,
                    peak.border = input$peak,
                    verbose = as.logical(input$verbose))
    data.frame(pVal = format(results$pVal, scientific = TRUE),
               phase = as.integer(results$phase),
               peak.shape = as.integer(results$peak.shape),
               period = as.integer(results$period)) %>%
      DT::datatable(options = list(pageLength = 20), rownames = FALSE)
  })

  observeEvent(input$refresh, {
    newData <- reactive({
      if (is.null(datafile())) return(NULL)
      readRDS(datafile()$datapath)
    })
    output$rain_matrix <- DT::renderDT({
      if(is.null(newData())) return(NULL)
      results <- rain(t(as.matrix(newData())),
                      deltat = input$num1,
                      period = input$num2,
                      nr.series = input$num3,
                      peak.border = input$peak,
                      verbose = as.logical(input$verbose))
      data.frame(pVal = results$pVal, phase = as.integer(results$phase), peak.shape = as.integer(results$peak.shape), period = as.integer(results$period)) %>%
        DT::datatable(options = list(pageLength = 20), rownames = FALSE)
    })
  })

  output$download_data <- downloadHandler(
    filename = function() {
      paste("results", ".csv", sep = "")
    },
    content = function(file) {
      if(is.null(data())) return(NULL)
      results <- rain(t(as.matrix(data())),
                      deltat = input$num1,
                      period = input$num2,
                      nr.series = input$num3,
                      peak.border = input$peak,
                      verbose = as.logical(input$verbose))
      write.csv(results, file, row.names = FALSE)
    }
  )

}

shinyApp(ui = ui, server = server)
